package com.example.bubblenew;

/**
 * Created by bijoysingh on 2/19/17.
 */

public class DefaultFloatingBubbleTouchListener implements FloatingBubbleTouchListener {
    @Override
    public void onDown(float x, float y) {

    }

    @Override
    public void onTap(boolean expanded) {

    }

    @Override
    public void onRemove() {

    }

    @Override
    public void onMove(float x, float y) {

    }

    @Override
    public void onUp(float x, float y) {

    }
}
