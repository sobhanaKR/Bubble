package com.example.bubblenew;

import android.app.Service;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;

import androidx.core.content.ContextCompat;

public class BubbleActivity extends FloatingBubbleService {

    @Override
    protected FloatingBubbleConfig getConfig() {
        Context context = getApplicationContext();
        return new FloatingBubbleConfig.Builder()
                .bubbleIcon(ContextCompat.getDrawable(context, R.drawable.web_icon))
                .removeBubbleIcon(ContextCompat.getDrawable(context, com.example.bubblenew.R.drawable.close_default_icon))
                .bubbleIconDp(80)
                .expandableView(getInflater().inflate(R.layout.sample_view_1, null))
                .removeBubbleIconDp(70)
                .paddingDp(4)
                .borderRadiusDp(0)
                .physicsEnabled(true)
                .expandableColor(Color.WHITE)
                .triangleColor(0xFF215A64)
                .gravity(Gravity.LEFT)
                .build();
    }
}
